package ing_soft_tiendit_os;

public class Ing_soft_TIENDIT_OS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
